package com.ust.books.domain;

public class Author {
}
