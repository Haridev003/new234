package com.ust.authors.service;

import com.ust.authors.domain.Author;
import com.ust.authors.domain.Book;
import com.ust.authors.repository.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class AuthorServiceImpl implements AuthorService {
    @Autowired
    private AuthorRepository authorRepository;
    @Autowired
    private RestTemplate restTemplate;

    @Override
    public List<Book> findBooksByAuthor(String author) {
        var response = restTemplate.getForEntity("http://BOOKS-SERVICE/books/s/{author}",
                Book[].class, author);
        if (response.hasBody()) {
            return Arrays.stream(response.getBody()).toList();
        }
        return List.of();
    }

    @Override
    public Author create(Author author) {
        authorRepository.save(author);
        return author;
    }

    @Override
    public Optional<Author> findByName(String name) {
        Optional<Author> optionalAuthor = authorRepository.findByName(name);
        return optionalAuthor;
    }
}
