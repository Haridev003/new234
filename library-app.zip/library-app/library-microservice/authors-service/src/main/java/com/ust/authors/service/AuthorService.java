package com.ust.authors.service;

import com.ust.authors.domain.Author;
import com.ust.authors.domain.Book;

import java.util.List;
import java.util.Optional;

public interface AuthorService {

    List<Book> findBooksByAuthor(String author);

    Author create(Author author);

    Optional<Author> findByName(String name);
}
